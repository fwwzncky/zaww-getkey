# Zaww Getkey

Key system untuk script — website + API + Upstash Redis.

## Deploy

1. Push repo ini ke GitHub
2. Import ke Vercel
3. Buat database di https://console.upstash.com (free tier)
4. Copy `UPSTASH_REDIS_REST_URL` dan `UPSTASH_REDIS_REST_TOKEN`
5. Set kedua env var itu di Vercel → Settings → Environment Variables
6. Redeploy

## Endpoint

- `POST /api/key/create` — buat key baru
- `POST /api/key/verify` — verify dari script (`{code, hwid}`)
- `POST /api/key/redeem` — manual redeem
- `POST /api/key/reset` — lepas binding device
- `POST /api/key/delete` — hapus key
- `GET  /api/keys` — list semua key
- `POST /api/order/create` — order premium
- `GET  /api/orders` — list order
- `GET  /api/stats` — statistik

## Test
