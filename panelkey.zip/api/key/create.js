const { getDB, setDB, createKeyIn, pubKey, json, body, preflight } = require('../_lib.js');

module.exports = async function handler(req, res) {
  if (preflight(req, res)) return;
  if (req.method !== 'POST') return json(res, { error: 'method_not_allowed' }, 405);
  try {
    const b  = await body(req);
    const DB = await getDB();
    const k  = createKeyIn(DB, b);
    if (!k) return json(res, { ok: false, reason: 'code_taken' }, 409);
    await setDB(DB);
    json(res, { ok: true, key: pubKey(k) });
  } catch (e) {
    json(res, { error: 'server_error', message: String(e) }, 500);
  }
};