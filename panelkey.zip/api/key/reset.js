const { getDB, setDB, json, body, preflight } = require('../_lib.js');

module.exports = async function handler(req, res) {
  if (preflight(req, res)) return;
  if (req.method !== 'POST') return json(res, { error: 'method_not_allowed' }, 405);
  try {
    const b  = await body(req);
    const DB = await getDB();
    const k  = DB.keys.find(x => x.code === (b.code || '').trim().toUpperCase());
    if (!k) return json(res, { ok: false, reason: 'not_found' });
    k.devices = [];
    await setDB(DB);
    json(res, { ok: true });
  } catch (e) {
    json(res, { error: 'server_error', message: String(e) }, 500);
  }
};