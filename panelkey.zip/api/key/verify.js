const { getDB, setDB, redeemIn, pubKey, json, body, preflight } = require('../_lib.js');

module.exports = async function handler(req, res) {
  if (preflight(req, res)) return;
  if (req.method !== 'POST') return json(res, { error: 'method_not_allowed' }, 405);
  try {
    const b = await body(req);
    if (!b.code) return json(res, { valid: false, reason: 'missing_code' });

    const code = b.code.trim().toUpperCase();
    const DB   = await getDB();
    const k    = DB.keys.find(x => x.code === code);

    if (!k) return json(res, { valid: false, reason: 'key_not_found' });
    if (k.expiresAt && Date.now() > k.expiresAt) return json(res, { valid: false, reason: 'expired' });

    if (!b.hwid) return json(res, { valid: true, expiresAt: k.expiresAt, key: pubKey(k) });

    if (!k.devices.includes(b.hwid)) {
      const r = redeemIn(DB, code, b.hwid);
      await setDB(DB);
      return json(res, {
        valid: r.ok, reason: r.reason,
        expiresAt: r.key ? r.key.expiresAt : k.expiresAt,
        key: r.key ? pubKey(r.key) : null
      });
    }

    json(res, { valid: true, reason: 'ok', expiresAt: k.expiresAt, key: pubKey(k) });
  } catch (e) {
    json(res, { error: 'server_error', message: String(e) }, 500);
  }
};