const { getDB, setDB, json, body, preflight } = require('../_lib.js');

module.exports = async function handler(req, res) {
  if (preflight(req, res)) return;
  if (req.method !== 'POST') return json(res, { error: 'method_not_allowed' }, 405);
  try {
    const b  = await body(req);
    const DB = await getDB();
    const before = DB.keys.length;
    DB.keys = DB.keys.filter(x => x.id !== b.id);
    await setDB(DB);
    json(res, { ok: DB.keys.length < before });
  } catch (e) {
    json(res, { error: 'server_error', message: String(e) }, 500);
  }
};