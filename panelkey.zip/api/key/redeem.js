const { getDB, setDB, redeemIn, pubKey, json, body, preflight } = require('../_lib.js');

module.exports = async function handler(req, res) {
  if (preflight(req, res)) return;
  if (req.method !== 'POST') return json(res, { error: 'method_not_allowed' }, 405);
  try {
    const b = await body(req);
    if (!b.code || !b.hwid) return json(res, { ok: false, reason: 'missing_fields' }, 400);
    const DB = await getDB();
    const r  = redeemIn(DB, b.code.trim().toUpperCase(), b.hwid);
    await setDB(DB);
    json(res, { ok: r.ok, reason: r.reason, key: r.key ? pubKey(r.key) : null });
  } catch (e) {
    json(res, { error: 'server_error', message: String(e) }, 500);
  }
};