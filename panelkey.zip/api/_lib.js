const { Redis } = require('@upstash/redis');

const DB_KEY = 'zaww_db';
let redisClient = null;

// Inisialisasi Redis secara aman (tidak crash saat server nyala)
function getRedis() {
  if (redisClient) return redisClient;
  
  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  
  if (!url || !token) {
    throw new Error('ENV_ERROR: Vercel tidak menemukan UPSTASH_REDIS_REST_URL atau TOKEN. Pastikan sudah diisi di Settings → Environment Variables.');
  }
  
  redisClient = new Redis({ url, token });
  return redisClient;
}

const CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const seg   = n => Array.from({ length: n }, () => CHARS[Math.floor(Math.random() * CHARS.length)]).join('');
const genCode = () => `ZAWW-${seg(4)}-${seg(4)}-${seg(4)}`;

async function getDB() {
  const redis = getRedis();
  const raw = await redis.get(DB_KEY);
  const db  = raw ? (typeof raw === 'string' ? JSON.parse(raw) : raw) : { keys: [], orders: [] };
  if (!Array.isArray(db.keys))   db.keys   = [];
  if (!Array.isArray(db.orders)) db.orders = [];
  return db;
}

async function setDB(db) {
  const redis = getRedis();
  await redis.set(DB_KEY, JSON.stringify(db));
}

function statusOf(k) {
  if (k.expiresAt && Date.now() > k.expiresAt) return 'expired';
  if (k.devices.length >= k.maxUsers)          return 'full';
  if (k.devices.length > 0)                    return 'active';
  return 'unused';
}

function pubKey(k) {
  return {
    id: k.id, code: k.code, type: k.type,
    durationHours: k.durationHours, maxUsers: k.maxUsers,
    devices: k.devices, createdAt: k.createdAt,
    activatedAt: k.activatedAt, expiresAt: k.expiresAt,
    status: statusOf(k)
  };
}

function createKeyIn(DB, { type = 'normal', hours = 24, slots = 1, custom = '' }) {
  let code = (custom || '').trim().toUpperCase();
  if (code && !code.startsWith('ZAWW-')) code = 'ZAWW-' + code.replace(/^ZAWW-?/i, '');
  if (code && DB.keys.some(k => k.code === code)) return null;
  if (!code) do { code = genCode(); } while (DB.keys.some(k => k.code === code));

  const key = {
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
    code, type,
    durationHours: Number(hours) || 0,
    maxUsers: Math.max(1, Number(slots) || 1),
    devices: [],
    createdAt: Date.now(),
    activatedAt: null,
    expiresAt: null
  };
  DB.keys.unshift(key);
  return key;
}

function redeemIn(DB, code, hwid) {
  const k = DB.keys.find(x => x.code === code);
  if (!k) return { ok: false, reason: 'key_not_found' };
  if (k.expiresAt && Date.now() > k.expiresAt) return { ok: false, reason: 'expired' };
  if (k.devices.includes(hwid))                return { ok: true,  reason: 'already_bound', key: k };
  if (k.devices.length >= k.maxUsers)          return { ok: false, reason: 'slot_full' };

  if (!k.activatedAt) {
    k.activatedAt = Date.now();
    if (k.durationHours > 0) k.expiresAt = k.activatedAt + k.durationHours * 3600000;
  }
  k.devices.push(hwid);
  return { ok: true, reason: 'redeemed', key: k };
}

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type'
};

function json(res, obj, status) {
  res.writeHead(status || 200, Object.assign({ 'Content-Type': 'application/json' }, CORS));
  res.end(JSON.stringify(obj));
}

function body(req) {
  return new Promise(resolve => {
    let b = '';
    req.on('data', c => { b += c; });
    req.on('end', () => {
      try { resolve(JSON.parse(b || '{}')); }
      catch { resolve({}); }
    });
  });
}

function preflight(req, res) {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, CORS);
    res.end();
    return true;
  }
  return false;
}

module.exports = {
  redis: getRedis, DB_KEY,
  genCode, getDB, setDB,
  statusOf, pubKey, createKeyIn, redeemIn,
  CORS, json, body, preflight
};