const { getDB, statusOf, json, preflight } = require('./_lib.js');

module.exports = async function handler(req, res) {
  if (preflight(req, res)) return;
  try {
    const DB = await getDB();
    json(res, {
      total:   DB.keys.length,
      active:  DB.keys.filter(k => statusOf(k) === 'active').length,
      premium: DB.keys.filter(k => k.type === 'premium').length,
      orders:  DB.orders.length
    });
  } catch (e) {
    json(res, { error: 'server_error', message: String(e) }, 500);
  }
};