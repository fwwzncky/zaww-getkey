const { getDB, pubKey, json, preflight } = require('./_lib.js');

module.exports = async function handler(req, res) {
  if (preflight(req, res)) return;
  try {
    const DB = await getDB();
    json(res, { keys: DB.keys.map(pubKey) });
  } catch (e) {
    json(res, { error: 'server_error', message: String(e) }, 500);
  }
};