const { getDB, json, preflight } = require('./_lib.js');

module.exports = async function handler(req, res) {
  if (preflight(req, res)) return;
  try {
    const DB = await getDB();
    json(res, { orders: DB.orders });
  } catch (e) {
    json(res, { error: 'server_error', message: String(e) }, 500);
  }
};